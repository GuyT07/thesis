/*
  Copyright 2006 by Sean Luke
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
 */

package ec.app.testar.nodes;

import ec.app.testar.StrategyNode;

public class LeftClicksAvailable extends StrategyNode {

    private static final long serialVersionUID = 1L;

    public LeftClicksAvailable() {
        name = "left-clicks-available:";
        letter = 'H';
        expectedChildren = 0;
    }

}
