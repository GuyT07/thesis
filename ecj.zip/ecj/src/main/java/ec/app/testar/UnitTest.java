//package ec.app.testar;
//
//import org.junit.Test;
//
//import java.util.TreeMap;
//
//import static org.junit.Assert.*;
//
//public class UnitTest {
//
//    @Test
//    public void testReader() {
//        TestarResultsReader reader = new TestarResultsReader();
//        TreeMap<String, String> result;
//
//        result = reader.getResults(25);
//
//        for (String key : result.keySet()) {
//            System.out.println(key + ": " + result.get(key));
//        }
//        assertNotNull(result);
//    }
//
//}
