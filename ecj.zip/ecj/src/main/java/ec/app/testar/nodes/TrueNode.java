package ec.app.testar.nodes;

import ec.app.testar.StrategyNode;

public class TrueNode extends StrategyNode {
    private static final long serialVersionUID = 1L;

    public TrueNode() {
        name = "true:";
        letter = '-';
        expectedChildren = 0;
    }

}
