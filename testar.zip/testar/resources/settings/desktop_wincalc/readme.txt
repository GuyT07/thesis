SUT specific
------------

- Double-clicking the MenuItem "Sistema" (System) will close the SUT.
	-> Two fast consecutive single clicks will act as a double click, hence closing the SUT
	-> fix: filter the "System" or "Sistema" MenuItem actions